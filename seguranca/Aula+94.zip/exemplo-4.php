<script src="https://www.google.com/recaptcha/api.js"></script>
<form action="cadastrar.php" method="post">

    <div class="g-recaptcha" data-sitekey="6LfV2hgUAAAAALCODft3IfKbEdDu_tJNLyRlesYg"></div>
    <input type="email" name="inputEmail">
    <button type="submit">Enviar</button>

</form>